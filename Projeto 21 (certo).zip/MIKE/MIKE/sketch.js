//Bugs desse jogo não consigo consertar
var PLAY = 1;
var END = 0;
var gameState = PLAY;
var bow , background, redB, pinkB, greenB ,blueB ,grayB;
var jogadorImage, brancoImage, policiaImage, cianoImage ,azulImage, RoadImage ,grayImage
var som;
var nuvensImage;
var começarImage;
var fimImage;
var veloImage;
var score =0;
var gameState ="serve";
var ligar;
var sirene;
var buzina;
var bow_colided;
var batida;
var nig
var beat
var batidas = 0;
var score = 0;

function preload(){
  
  //carregamento de imagens e som do jogo
  RoadImage = loadImage("Road.png");
  começarImage = loadImage("começar.png")
  fimImage = loadImage("fim.png")
  grayImage = loadImage("gray.png");
  boomImage = loadImage("gray.png")
  enterImage = loadImage("enter.png");
  veloImage = loadImage("velo.png");
  nuvensImage = loadImage("nuvens.png")
  jogadorImage = loadImage("jogador.png");
  policiaImage = loadImage("policia.png");
  brancoImage = loadImage("branco.png");
  cianoImage = loadImage("ciano.png");
  azulImage = loadImage("azul.png");
  beat = loadSound("beat.mp3")
  ligar = loadSound("ligar.mp3");
  batida = loadSound("batida.mp3");
  sirene = loadSound("sirene.mp3");
  buzina = loadSound("buzina.mp3");
}



function setup() {
  createCanvas(windowWidth, windowHeight);

  //musica e efeito sonoro em loop infinito
  beat.loop();
  ligar.loop();

  //O fundo
  scene = createSprite(0,200,400,400);
  scene.addImage(RoadImage);
  scene.scale = 1,0;
  

  //informação do butão de começar
 enter = createSprite(650,100,60,60)
 enter.addImage(enterImage);
 enter.scale = 0.3


  //Fim de jogo (invisivel)
  fim = createSprite(650,200,60,60);
  fim.visible = false;
 
  //Começar (visivel)
  começar = createSprite(650,280,60,60);
  começar.addImage(começarImage)

  //Imagem do velocimetro do carro
  velo = createSprite(100,60,20,50)
  velo.addImage(veloImage)
  velo.scale = 0.3

//O carro
bow = createSprite(900,220,20,50);
  bow.addImage(jogadorImage); 
  bow.scale = 0.133
  bow.debug = false;
  bow.visible = false
  bow.setCollider('rectangle',0,-30,950,499,360);


  //Grupos dos carros
  redB= new Group();
  
  greenB= new Group();

 blueB= new Group();
 
 pinkB= new Group();

 
 //borda do jogo (onde o nosso carro colide)
 edges= createEdgeSprites();

 
 
}

 


 
function draw() {

  


//informação desnecessaria mas porem, util
 background(0);

 //carro colide com as bordas
 bow.collide(edges);
 

  //Nosso carro colide com os carros e da fim de jogo
 if (redB.isTouching(bow)) {
  gameState = END;
  fim.addImage(fimImage)
  batidas = batidas + 1;
  sirene.play();
  
  redB.bounceOff(bow)
  blueB.bounceOff(bow)
  greenB.collide(bow)
  pinkB.collide(bow)
  batida.play();
  fim.visible = true;
}


if (greenB.isTouching(bow)) {
  gameState = END;
  batidas = batidas + 1;
  
  redB.collide(bow)
  blueB.collide(bow)
  greenB.bounceOff(bow)
  pinkB.collide(bow)
  batida.play();
  fim.visible = true;
  fim.addImage(fimImage)
}

if (blueB.isTouching(bow)) {
  gameState = END;
  batidas = batidas + 1;
  redB.collide(bow);
  blueB.bounceOff(bow)
  batida.play();
  fim.visible = true;
  fim.addImage(fimImage)
}

if (pinkB.isTouching(bow)) {
  gameState = END;
  batidas = batidas + 1;

  redB.collide(bow);
  blueB.collide(bow);
  greenB.collide(bow);
  pinkB.bounceOff(bow);
  batida.play();
  fim.visible = true;
  fim.addImage(fimImage)
}
 
 
 //Aperta botão enter para começar a jogar
 if (keyDown("ENTER")) {
  enter.destroy();
  redB.destroyEach();
  blueB.destroyEach();
  greenB.destroyEach();
  pinkB.destroyEach();
  gameState= PLAY;
  fill("red")
  score = score = 0;
  
}
  
  //pontuação a chegar a 100 irar buzinar
if (score>0 && score%100 === 0){
  buzina.play();
  fill("red")
}



 //buzinar ao aperta "espaço"
if (keyDown("space")){
buzina.play();
}
 


  //começar a jogar
 if(gameState === PLAY){


  //pontuação do jogador
  score = score + Math.round(getFrameRate()/60);
  
  //imagens ira desaparecer quando começarmos a jogar
  fim.visible = false;
  começar.visible = false;
  bow.visible = true;


  //chão em movimento
    scene.velocityX = -44 
    

    //chão infinito
    if (scene.x < 0){
      scene.x = scene.width/10;
    }
  


  //carro em movimento (controle do carro)
  if (keyDown("LEFT_ARROW")) {
    bow.x = bow.x -8;
  }
  
  if (keyDown("RIGHT_ARROW")) {
    bow.x = bow.x +8;
  }
  
  if (keyDown("UP_ARROW")) {
    bow.y = bow.y -8;
  }
  
  if (keyDown("DOWN_ARROW")) {
    bow.y = bow.y +8;
  }

 
  }


  //criando carros continuamente
  var select_balloon = Math.round(random(1,4));
  
  if (World.frameCount % 50 == 0) {
    
    switch(select_balloon ){
      case 1: redBalloon();
      break;
      case 2:blueBalloon();
      break;
      case 3:pinkBalloon();
      break;
      case 4:greenBalloon();
      break;
      default:break;
    }
  }
   
  drawSprites();

  //estruções
  textSize(40);
  text("KMH:" + score,200,50)
  text("aperte enter para começar !", 600,650);
  fill("0")
  text("batidas:" + batidas ,150,500);
  textSize(23);
  text("Desvie dos carros com as setas do teclado!",20, 300,50);
  text("aperte espaço para Buzinar!",90, 340,50);

  
  //fim de jogo
  if (gameState === END) {
    fill("1")
    textSize(70);
    text("aperte enter para recomeçar!", 300,50);
    fill("yellow")
    text("SUA PONTUAÇÃO:" + score,400,400)
    
  scene.velocityX = 0;
  pinkB.velocityX = 0;
  
}


}

//carro da policia de forma aleatoria
function redBalloon() {
  if(frameCount % 60 === 0 ){
  var red = createSprite(0,Math.round(random(600, 370)), 10, 10);
  redB.velocityX = -(44 + score/100);
  red.addImage(policiaImage);
  nuvens = createSprite(0,Math.round(random(900, 170)), 10, 10);
  nuvens.velocityX = 23;
  nuvens.addImage(nuvensImage)
  nuvens.scale = 0.3
  red.velocityX = 3;
  red.lifetime = 600;
  red.scale = 0.4;
  redB.add(red);
  
}
}

 //carro azul de forma aleatoria
function blueBalloon() {
  var blue = createSprite(0,Math.round(random(600, 370)), 10, 10);
  blue.addImage(azulImage);
  nuvens = createSprite(0,Math.round(random(600, 370)), 10, 10);
  nuvens.velocityX = 23;
  nuvens.addImage(nuvensImage)
  nuvens.scale = 0.3
  blue.velocityX = 7;
  blue.lifetime = 600;
  blue.scale = 0.4;
  
 blueB.add(blue)

}

 //carro branco de forma aleatoria
function greenBalloon() {
  var green = createSprite(0,Math.round(random(20, 370)), 10, 10);
  green.addImage(brancoImage);
  nuvens = createSprite(0,Math.round(random(600, 70)), 10, 10);
  nuvens.velocityX = 23;
  nuvens.addImage(nuvensImage)
  nuvens.scale = 0.3

  green.velocityX = 20;
  green.lifetime = 600;
  green.scale = 0.2;

  greenB.add(green)
}

 //carro ciano de forma aleatoria
function pinkBalloon() {
  var pink = createSprite(0,Math.round(random(20, 370)), 10, 10);
  pink.addImage(cianoImage);
  nuvens = createSprite(0,Math.round(random(600, 70)), 10, 10);
  nuvens.velocityX = 23;
  nuvens.addImage(nuvensImage)
  nuvens.scale = 0.3
  pink.velocityX = 14;
  pink.lifetime = 600;
  pink.scale = 0.4
 
 pinkB.add(pink)
}


